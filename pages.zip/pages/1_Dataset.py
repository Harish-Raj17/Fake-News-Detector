import streamlit as st
import pandas as pd
import base64

st.set_page_config(page_title="Fake News", layout="wide")


# Function to convert image to base64
def get_image_base64(file_path):
    with open(file_path, "rb") as img_file:
        return base64.b64encode(img_file.read()).decode()

# Get image as base64
image_base64 = get_image_base64("Sastra.jpg")  # Make sure the image is in your directory

# Inject the logo with absolute positioning
st.markdown(f"""
    <style>
        .top-right-logo {{
            position: absolute;
            top: 10px;
            right: 10px;
            z-index: 10;
        }}
    </style>
    <div class="top-right-logo">
        <img src="data:image/png;base64,{image_base64}" width="50">
    </div>
""", unsafe_allow_html=True)


st.title("Fake news Dataset Viewer")

data = pd.read_csv("data.csv")

st.markdown("Explore the processed Fake News dataset.")

st.dataframe(data, use_container_width=True)
