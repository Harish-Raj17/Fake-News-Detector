import streamlit as st
import numpy as np
import joblib
import os
import base64
import re
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing.text import Tokenizer

st.set_page_config(page_title="Fake News Predictor", layout="wide")

# Function to convert image to base64
def get_image_base64(file_path):
    try:
        with open(file_path, "rb") as img_file:
            return base64.b64encode(img_file.read()).decode()
    except FileNotFoundError:
        return None

# Inject logo in top-right corner
image_base64 = get_image_base64("Sastra.jpg")
if image_base64:
    st.markdown(f"""
        <style>
            .top-right-logo {{
                position: absolute;
                top: 10px;
                right: 10px;
                z-index: 10;
            }}
        </style>
        <div class="top-right-logo">
            <img src="data:image/png;base64,{image_base64}" width="50">
        </div>
    """, unsafe_allow_html=True)

# Title
st.markdown("<h2 style='text-align: center;'>Fake News Classifier</h2>", unsafe_allow_html=True)
st.write("Enter text and choose a model to classify the news as True or Fake.")

# Text preprocessing function
def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'[^\w\s]', '', text)
    text = re.sub(r'\d+', '', text)
    return text

# Text input
user_text = st.text_area("Enter text to classify:")

# Model choice
model_choice = st.selectbox(
    "Choose a model:",
    ["CNN (FastText)", "LSTM (GloVe)", "ResNet (GloVe)"]
)

# File paths and class names
CLASS_NAMES = ["True", "Fake"]
model_paths = {
    "CNN (FastText)": "mini_fasttext_cnn.h5",
    "LSTM (GloVe)": "lstm_model.keras",
    "ResNet (GloVe)": "resnet_model.keras"
}
tokenizer_paths = {
    "CNN (FastText)": "tokenizer_cnn.pkl",
    "LSTM (GloVe)": "tokenizer_glove.pkl",
    "ResNet (GloVe)": "tokenizer_glove.pkl"
}

MAX_SEQUENCE_LENGTH = 100

# Predict button
if st.button("Classify"):
    if user_text.strip():
        try:
            model_path = model_paths.get(model_choice)
            tokenizer_path = tokenizer_paths.get(model_choice)

            if os.path.exists(model_path) and os.path.exists(tokenizer_path):
                model = load_model(model_path)
                tokenizer = joblib.load(tokenizer_path)

                # Preprocess input
                processed_text = preprocess_text(user_text)
                sequence = tokenizer.texts_to_sequences([processed_text])
                padded = pad_sequences(sequence, maxlen=MAX_SEQUENCE_LENGTH)

                # Predict
                prediction = model.predict(padded)
                if prediction.ndim == 2:
                    predicted_index = np.argmax(prediction, axis=1)[0]
                else:
                    predicted_index = int(np.round(prediction[0]))

                predicted_class = CLASS_NAMES[predicted_index]
                confidence = np.max(prediction) * 100

                # Output
                color = "green" if predicted_class == "True" else "red"
                st.markdown(
                    f"<h3 style='text-align: center; color: {color};'>Prediction: {predicted_class}</h3>",
                    unsafe_allow_html=True
                )
                st.write(f"Confidence: {confidence:.2f}%")

                if predicted_class == "Fake":
                    st.warning("This content shows characteristics commonly associated with fake news. Verify with reliable sources.")
                else:
                    st.info("This content appears credible, but always verify information from multiple sources.")
            else:
                st.error("Model or tokenizer file not found. Please check the file paths and try again.")

        except Exception as e:
            st.error(f"Prediction error: {str(e)}")
            st.write("Technical details:")
            st.exception(e)
    else:
        st.warning("Please enter some text to analyze.")
