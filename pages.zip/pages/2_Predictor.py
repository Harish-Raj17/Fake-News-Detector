import streamlit as st
import numpy as np
import json
import re
import nltk
from nltk.corpus import stopwords
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing.text import tokenizer_from_json

# Download stopwords once (comment out after first run)
nltk.download('stopwords')
stop_words = set(stopwords.words('english'))

# Streamlit page config
st.set_page_config(page_title="Fake News Predictor", layout="wide")

@st.cache_data
def load_tokenizer(tokenizer_path="tokenizer_lstm.json"):
    with open(tokenizer_path, "r", encoding="utf-8") as f:
        tokenizer_json = f.read()
    tokenizer = tokenizer_from_json(tokenizer_json)
    return tokenizer

@st.cache_resource
def load_bilstm_model(model_path="mini_glove_lstm.keras"):
    model = load_model(model_path)
    return model

# Preprocessing function with all five steps
def preprocess_text(text, tokenizer, max_len=200):
    # 1. Lowercase
    text = text.lower()

    # 2. Remove punctuation (keep only letters and spaces)
    text = re.sub(r'[^a-z\s]', '', text)

    # 3. Remove stopwords
    tokens = text.split()
    filtered_tokens = [word for word in tokens if word not in stop_words]
    filtered_text = " ".join(filtered_tokens)

    # 4. Tokenize using the keras tokenizer
    sequences = tokenizer.texts_to_sequences([filtered_text])

    # 5. Pad sequences
    padded_seq = pad_sequences(sequences, maxlen=max_len, padding='post', truncating='post')

    return padded_seq

# Load tokenizer and model once
tokenizer = load_tokenizer()
model = load_bilstm_model()

st.markdown("<h2 style='text-align: center;'>Fake News Classifier - BiLSTM Model</h2>", unsafe_allow_html=True)
user_input = st.text_area("Enter news text to classify:")

if st.button("Classify"):
    if user_input.strip():
        max_len = 200  # Use your trained model's max length here

        # Preprocess input
        input_seq = preprocess_text(user_input, tokenizer, max_len)

        # Debug info
        st.write("Tokenizer vocabulary size:", len(tokenizer.word_index))
        st.write("Sample tokenizer word index:", list(tokenizer.word_index.items())[:10])
        st.write("Tokenized & padded input:", input_seq)

        # Prediction
        pred_prob = model.predict(input_seq)[0][0]

        # Debug raw output
        st.write(f"Model raw output (probability for True news): {pred_prob:.4f}")

        # Assuming model outputs prob(True), adjust if your labels are reversed
        predicted_label = "True" if pred_prob > 0.5 else "Fake"
        confidence = pred_prob if pred_prob > 0.5 else 1 - pred_prob
        confidence_percent = confidence * 100

        color = "green" if predicted_label == "True" else "red"
        st.markdown(f"<h3 style='text-align: center; color: {color};'>Prediction: {predicted_label}</h3>", unsafe_allow_html=True)
        st.write(f"Confidence: {confidence_percent:.2f}%")

    else:
        st.warning("Please enter some text to classify.")
